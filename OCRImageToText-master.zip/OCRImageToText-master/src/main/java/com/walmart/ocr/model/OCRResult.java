package com.walmart.ocr.model;

public class OCRResult {
	private String resultString;

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}
	

}
