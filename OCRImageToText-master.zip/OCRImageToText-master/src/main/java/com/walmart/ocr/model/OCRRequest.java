package com.walmart.ocr.model;

public class OCRRequest {
	private String imageURI;

	public String getImageURI() {
		return imageURI;
	}

	public void setImageURI(String imageURI) {
		this.imageURI = imageURI;
	}

}
