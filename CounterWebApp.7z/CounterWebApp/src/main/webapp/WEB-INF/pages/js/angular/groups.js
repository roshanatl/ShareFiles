var app = angular.module('GroupApp', ['ngCookies'])

app.config( [ '$locationProvider', function( $locationProvider ) {
	   // In order to get the query string from the
	   // $location object, it must be in HTML5 mode.
	   $locationProvider.html5Mode( true );
	}]);

app.controller('GroupController', ['$scope','$http','$cookieStore','$window', function ($scope, $http,$cookieStore,$window) {
		var hackUser =  $cookieStore.get("hackUserInfo");
		if(!hackUser){
			$window.location.href = 'page-login';
		}
	    $scope.hackUserInfo =  hackUser;
		
		$scope.logout=function(){
			$cookieStore.remove("hackUserInfo");
			$window.location.href = 'HomePage';
		};
		
		$scope.UserGroup={
                    groupName : "",
                    createdBy : ""
                };
		$scope.Users=[];
		$scope.groupUserMapping =  {"groupId":"","userId":""};
		//$scope.memberId=0;
		$scope.Groups=[];		
		$scope.success=false;
		_refreshPageData();
			
		$scope.listUser=function(){
			
			$http({
	            method : 'GET',
	            url : 'https://hack-rest.herokuapp.com/users'
	        }).then(function successCallback(response) {
	             $scope.Users= response.data;
				 console.log("success"+response.data);
	            
	        }, function errorCallback(response) {
	            console.log("Erro calling Item Service");
	        });
			
		};
		
		
		 $scope.addMember = function(ug) {debugger;
		var groupUserMapping =  {"groupId":ug.groupId,"userId":$scope.memberId};
            
                 $http({
                     method : "POST",
                     url : "https://hack-rest.herokuapp.com/groups/user",
                     data : angular.toJson(groupUserMapping),
                     headers : {
                         'Content-Type' : 'application/json'
                     }
                 }).then( _success, _error );
             };
	//HTTP POST/PUT methods for add/edit Group
                $scope.addGroup = function() {
                	
                $scope.UserGroup.createdBy=$scope.hackUserInfo.userId;
                   
                    $http({
                        method : "POST",
                        url : "https://hack-rest.herokuapp.com/groups",
                        data : angular.toJson($scope.UserGroup),
                        headers : {
                            'Content-Type' : 'application/json'
                        }
                    }).then( _success, _error );
                };
	
	function _refreshPageData() {
        $http({
            method : 'GET',
            url : 'https://hack-rest.herokuapp.com/groups?userId='+$scope.hackUserInfo.userId
        }).then(function successCallback(response) {
             $scope.Groups= response.data;
			 console.log("success"+response.data);
            
        }, function errorCallback(response) {
            console.log("Erro calling Item Service");
        });
    }

	 function _success(response) {debugger;
	              console.log("success");
				  $scope.success=true;
				  _refreshPageData() ;
                    
      }
      function _error(response) {
                    console.log("error");
      }
}]);
