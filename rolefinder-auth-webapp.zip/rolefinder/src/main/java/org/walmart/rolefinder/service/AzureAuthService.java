package org.walmart.rolefinder.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.walmart.rolefinder.bean.AuthRequest;
import org.walmart.rolefinder.bean.AuthResponse;
import org.walmart.rolefinder.bean.UserDetails;
import org.walmart.rolefinder.util.AzureClientUtil;

public class AzureAuthService {
	AzureClientUtil client = new AzureClientUtil();
	static AuthResponse savedAuthResponse = null;

	public AuthResponse getAccessToken(AuthRequest authRequest,boolean debugLogs) {
		AuthResponse authResponse = null;
		try {
			authResponse = client.getToken(authRequest.getCode(),debugLogs);
			savedAuthResponse = authResponse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return authResponse;
	}

	public List<UserDetails> getUserDetails(List<String> userId,
			String accesToken,boolean debugLogs) {
		List<UserDetails> userDetails = null;
		try {
			userDetails = (List<UserDetails>) client
					.getUser(userId, accesToken,debugLogs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userDetails;
	}

	public List<UserDetails> getRoleDetails(String userId, String accesToken,boolean debugLogs) {
		List<UserDetails> userDetails = null;
		Boolean exitLoop = false;
		Map<String, UserDetails> userMapStore = new LinkedHashMap<String, UserDetails>();
		try {
			// Get the reports of user.
			
			userDetails = (List<UserDetails>) client.findRole(userId,
					accesToken,debugLogs);
			// add to map store
			addtoMap(userDetails,userMapStore);
			// loop through each reports & find reports.
			if (null != userDetails && !userDetails.isEmpty()) {
				while (!exitLoop) {
					for (UserDetails user : userDetails) {
						userDetails = (List<UserDetails>) client.findRole(
								user.getUserId(), accesToken,debugLogs);
						// add to map store
						if (null == userDetails || userDetails.isEmpty()) {
							exitLoop = true;
						}
						else{
							exitLoop = false;
						}
						addtoMap(userDetails,userMapStore);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ArrayList<UserDetails>( userMapStore.values());
	}

	private Map<String, UserDetails> addtoMap(List<UserDetails> users,Map<String, UserDetails> userMapStore) {
		for(UserDetails user:users){
			if(user.getJobTitle().contains("Engineer")){
				userMapStore.put(user.getUserId(), user);
			}
			else{
				System.out.println("Ignoring User in Role filter : " + user.getDisplayName() + "role is :"+user.getJobTitle());
			}
		}

		return userMapStore;
	}
	
	
}
