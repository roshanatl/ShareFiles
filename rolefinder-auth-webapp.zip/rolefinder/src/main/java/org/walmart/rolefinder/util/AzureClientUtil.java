package org.walmart.rolefinder.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.walmart.rolefinder.bean.AuthResponse;
import org.walmart.rolefinder.bean.UserDetails;

public class AzureClientUtil {

	private String cookies;
	private HttpClient client = HttpClientBuilder.create().build();

	public AuthResponse getToken(String code, boolean debugLogs)
			throws Exception {

		String url = "https://login.microsoftonline.com/common/oauth2/token";
		HttpPost post = new HttpPost(url);

		// add header
		List<NameValuePair> paramList = new ArrayList<NameValuePair>();
		paramList
				.add(new BasicNameValuePair("grant_type", "authorization_code"));
		paramList.add(new BasicNameValuePair("redirect_uri",
				"http://localhost:8080/role-finder/auth.html"));
		paramList.add(new BasicNameValuePair("client_id",
				"5103f34b-35e7-47d3-add7-3e6529a96a78"));
		paramList.add(new BasicNameValuePair("client_secret",
				"CxoTynDiVnUReLHRO3SzlaurnE4RZlMhydzazVxJ+No="));
		paramList.add(new BasicNameValuePair("resource",
				"https://graph.windows.net"));
		paramList.add(new BasicNameValuePair("code", code));

		post.setHeader("Content-Type", "application/x-www-form-urlencoded");

		post.setEntity(new UrlEncodedFormEntity(paramList));

		HttpResponse response = client.execute(post);

		int responseCode = response.getStatusLine().getStatusCode();
		if (debugLogs) {
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + paramList);
			System.out.println("Response Code : " + responseCode);
			System.out.println("Response Code : " + response);
		}

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}

		JSONObject authResponseJson = new JSONObject(result.toString());
		if (debugLogs) {
			System.out.println(result.toString());

		}
		String accessToken = (String) authResponseJson.get("access_token");
		if (debugLogs) {
			System.out.println(accessToken);

		}
		AuthResponse authResponse = new AuthResponse();
		authResponse.setAccessToken(accessToken);
		// authResponse.setExpiresOn(expiresOn);
		return authResponse;

	}

	public List<UserDetails> findRole(String userId, String accessToken,
			boolean debugLogs) throws Exception {
		List<UserDetails> userDetails = new ArrayList<UserDetails>();
		String auth = "Bearer " + accessToken;

		HttpGet request = new HttpGet(
				"https://graph.windows.net/wal-mart.com/users/"
						+ userId
						+ "@homeoffice.wal-mart.com/directReports?api-version=1.6");

		request.setHeader("Authorization", auth);

		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		if (debugLogs) {
			System.out.println("\nSending 'GET' request to get user  : "
					+ userId);
			System.out.println("Response Code : " + responseCode);
			System.out.println(response);
		}
		if (200 == responseCode) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			if (null != userJsonResponse.get("value")) {
				JSONArray userJsonArray = (JSONArray) userJsonResponse
						.get("value");
				if (!userJsonArray.isNull(0)) {
					for (int i = 0; i < userJsonArray.length(); i++) {
						UserDetails userDetail = new UserDetails();
						if (null != userJsonArray.get(i)) {
							JSONObject user = new JSONObject(userJsonArray.get(
									i).toString());
							userDetail.setEmail(user.get("mail").toString());
							userDetail.setDisplayName(user.get("displayName")
									.toString());
							userDetail.setPhone(user.get("telephoneNumber")
									.toString());
							userDetail.setUserId(user.get("mailNickname")
									.toString());
							userDetail.setJobTitle(user.get("jobTitle")
									.toString());
							userDetail.setDepartment(user.get("department")
									.toString());
							getManagerDetails(userDetail, accessToken,
									debugLogs);
							userDetails.add(userDetail);
						}
					}
				}
			} else if (null != userJsonResponse.get("mail")) {
				UserDetails userDetail = new UserDetails();
				userDetail.setEmail((String) userJsonResponse.get("mail"));
				userDetail.setDisplayName((String) userJsonResponse
						.get("displayName"));
				userDetail.setPhone((String) userJsonResponse
						.get("telephoneNumber"));
				userDetail.setUserId((String) userJsonResponse
						.get("mailNickname"));
				userDetail.setJobTitle((String) userJsonResponse
						.get("jobTitle"));
				userDetail.setDepartment((String) userJsonResponse
						.get("department"));
				getManagerDetails(userDetail, accessToken, debugLogs);
				userDetails.add(userDetail);
			}
		}
		// userDetails.setUserId((String) userJson.get("access_token"));
		return userDetails;

	}

	private UserDetails getManagerDetails(UserDetails userDetails,
			String accessToken, boolean debugLogs)
			throws ClientProtocolException, IOException, JSONException {

		String auth = "Bearer " + accessToken;

		HttpGet request = new HttpGet(
				"https://graph.windows.net/wal-mart.com/users/"
						+ userDetails.getUserId()
						+ "@homeoffice.wal-mart.com/manager?api-version=1.6");

		request.setHeader("Authorization", auth);

		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();

		if (debugLogs) {
			System.out
					.println("\nSending 'GET' request to get user manager details : "
							+ userDetails.getUserId());
			System.out.println("Response Code : " + responseCode);
			System.out.println(response);
		}
		if (200 == responseCode) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			userDetails.setReportsTo((String) userJsonResponse
					.get("displayName"));
			userDetails.setManegerEmail((String) userJsonResponse.get("mail"));
		}
		return userDetails;

	}

	public List<UserDetails> getUser(List<String> userIds, String accessToken,
			boolean debugLogs) throws Exception {
		List<UserDetails> userDetails = new ArrayList<UserDetails>();
		String auth = "Bearer " + accessToken;
		for (String userId : userIds) {

			HttpGet request = new HttpGet(
					"https://graph.windows.net/wal-mart.com/users?$filter=mailNickname%20eq%20%27"
							+ userId + "%27&api-version=1.6");

			request.setHeader("Authorization", auth);

			HttpResponse response = client.execute(request);
			int responseCode = response.getStatusLine().getStatusCode();
			if (debugLogs) {

				System.out.println("\nSending 'GET' request to get user  : "
						+ userId);
				System.out.println("Response Code : " + responseCode);
				System.out.println(response);
			}
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			JSONArray userJsonArray = (JSONArray) userJsonResponse.get("value");

			for (int i = 0; i < userJsonArray.length(); i++) {
				UserDetails userDetail = new UserDetails();
				JSONObject user = new JSONObject(userJsonArray.get(i)
						.toString());

				userDetail.setEmail((String) user.get("mail"));
				userDetail.setDisplayName((String) user.get("displayName"));
				userDetail.setPhone((String) user.get("telephoneNumber"));
				userDetail.setUserId((String) user.get("mailNickname"));

				userDetails.add(userDetail);
			}

		}
		return userDetails;

	}

	public String getCookies() {
		return cookies;
	}

	public void setCookies(String cookies) {
		this.cookies = cookies;
	}

}