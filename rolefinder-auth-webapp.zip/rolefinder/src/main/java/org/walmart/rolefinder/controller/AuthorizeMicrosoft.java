package org.walmart.rolefinder.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;

import org.walmart.rolefinder.bean.AuthRequest;
import org.walmart.rolefinder.bean.AuthResponse;
import org.walmart.rolefinder.bean.UserDetails;
import org.walmart.rolefinder.service.AzureAuthService;

@Path("/auth")
public class AuthorizeMicrosoft {

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public AuthResponse getToken(AuthRequest authRequest) {
		AuthResponse authResponse = new AuthResponse();
		AzureAuthService azureAuthService = new AzureAuthService();
		authResponse=azureAuthService.getAccessToken(authRequest,true);
		return authResponse;
	}
	@Path("/users")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<UserDetails> getuserDetails(@Context UriInfo info) {
		
		String userIdsString = info.getQueryParameters().getFirst("userIds");
		String[] userIdArray = userIdsString.split(",");
		AzureAuthService azureAuthService = new AzureAuthService();
		String accesToken = info.getQueryParameters().getFirst("accesToken");
		return azureAuthService.getUserDetails(Arrays.asList(userIdArray),accesToken,true);
	}
	@Path("/roles")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<UserDetails> getroleDetails(@Context UriInfo info) {
		
		String userIdsString = info.getQueryParameters().getFirst("userId");
		AzureAuthService azureAuthService = new AzureAuthService();
		String accesToken = info.getQueryParameters().getFirst("accesToken");
		return azureAuthService.getRoleDetails(userIdsString,accesToken,true);
	}
	@GET
	  @Path("/download")
	  @Produces(MediaType.APPLICATION_OCTET_STREAM)
	  public Response downloadFilebyPath(@Context UriInfo info) {
		  Response res=null;
	    try {
	    	 String accesToken = info.getQueryParameters().getFirst("accesToken");
	    	 String userId = info.getQueryParameters().getFirst("userId");
	    	 AzureAuthService azureAuthService = new AzureAuthService();
	    	 List<UserDetails> users = azureAuthService.getRoleDetails(userId,accesToken,true);
	    	res= download(users);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return res;
	  }
	@GET
	  @Path("/downloadContacts")
	  @Produces(MediaType.APPLICATION_OCTET_STREAM)
	  public Response downloadContacts(@Context UriInfo info) {
		  Response res=null;
	    try {
	    	 String accesToken = info.getQueryParameters().getFirst("accesToken");
	    	 String userId = info.getQueryParameters().getFirst("userId");
	    	 String[] userIdArray = userId.split(",");
	    	 AzureAuthService azureAuthService = new AzureAuthService();
	    	 List<UserDetails> users = azureAuthService.getUserDetails(Arrays.asList(userIdArray),accesToken,true);
	    	res= downloadContacts(users);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return res;
	  }

	private Response download( List<UserDetails> users) throws FileNotFoundException  {     
	    String fileName = "Output_Role_finder.csv";
	    Response response = null;
	    NumberFormat myFormat = NumberFormat.getInstance();
	      myFormat.setGroupingUsed(true);
	    
	    // Retrieve the file 
	   File file = new File(fileName);
	    PrintWriter pw = new PrintWriter(file);
	    StringBuilder sbTitle = new StringBuilder();
	    sbTitle.append("UserID$Name$Title$Department$EmailID$PhoneNo$Reports To$Manager's Email");
	    pw.write(sbTitle.toString());
	    for(UserDetails user:users){
	    StringBuilder sb = new StringBuilder();
	    sb.append(user.getUserId());
	    sb.append('$');
	    sb.append(user.getDisplayName());
	    sb.append('$');
	    sb.append(user.getJobTitle());
	    sb.append('$');
	    sb.append(user.getDepartment());
	    sb.append('$');
	    sb.append(user.getEmail());
	    sb.append('$');
	    sb.append(user.getPhone());
	    sb.append('$');
	    sb.append(user.getManegerEmail());
	    sb.append('$');
	    sb.append(user.getReportsTo());
	    sb.append('\n');

	    pw.write(sb.toString());
	    
	    System.out.println("done!");
	    }
	    
	    pw.close();
	      ResponseBuilder builder = Response.ok(file);
	      builder.header("Content-Disposition", "attachment; filename=" + file.getName());
	      response = builder.build();
	      
	    /*  long file_size = file.length();
	            logger.info(String.format("Inside downloadFile==> fileName: %s, fileSize: %s bytes", 
	                fileName, myFormat.format(file_size)));*/
	  
	    return response;
	  }
	private Response downloadContacts( List<UserDetails> users) throws FileNotFoundException  {     
	    String fileName = "Output_Contact_Finder.txt";
	    Response response = null;
	   
	    
	    // Retrieve the file 
	   File file = new File(fileName);
	    PrintWriter pw = new PrintWriter(file);
	   
	    for(UserDetails user:users){
	    StringBuilder sb = new StringBuilder();
	    sb.append(user.getUserId());
	    sb.append('$');
	    sb.append(user.getDisplayName());
	    sb.append('$');
	    sb.append(user.getJobTitle());
	    sb.append('$');	   
	    sb.append(user.getEmail());
	    sb.append('$');
	    sb.append(user.getPhone());	    
	    //sb.append('\n');

	    pw.println(sb.toString());
	    
	    System.out.println("done!");
	    }
	    
	    pw.close();
	      ResponseBuilder builder = Response.ok(file);
	      builder.header("Content-Disposition", "attachment; filename=" + file.getName());
	      response = builder.build();
	      
	    /*  long file_size = file.length();
	            logger.info(String.format("Inside downloadFile==> fileName: %s, fileSize: %s bytes", 
	                fileName, myFormat.format(file_size)));*/
	  
	    return response;
	  }

}