package com.walmart.hackathon.model;

public class Item {

}
