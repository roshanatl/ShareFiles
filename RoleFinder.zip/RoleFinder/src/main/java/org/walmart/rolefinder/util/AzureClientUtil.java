package org.walmart.rolefinder.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.walmart.rolefinder.bean.AuthResponse;
import org.walmart.rolefinder.bean.UserDetails;

public class AzureClientUtil {

	private HttpClient client = HttpClientBuilder.create().build();

	public static void main(String[] args) throws Exception {

	}

	public AuthResponse getToken(String code, boolean debugLogs)
			throws Exception {

		String url = "https://login.microsoftonline.com/common/oauth2/token";
		HttpPost post = new HttpPost(url);

		// add header
		List<NameValuePair> paramList = new ArrayList<NameValuePair>();
		paramList
				.add(new BasicNameValuePair("grant_type", "authorization_code"));
		paramList.add(new BasicNameValuePair("redirect_uri",
				"http://localhost:8888/auth"));
		/*
		 * paramList.add(new BasicNameValuePair("redirect_uri",
		 * "https://role-finder.herokuapp.com/auth.html"));
		 */
		paramList.add(new BasicNameValuePair("client_id",
				"5103f34b-35e7-47d3-add7-3e6529a96a78"));
		paramList.add(new BasicNameValuePair("client_secret",
				"CxoTynDiVnUReLHRO3SzlaurnE4RZlMhydzazVxJ+No="));
		paramList.add(new BasicNameValuePair("resource",
				"https://graph.windows.net"));
		paramList.add(new BasicNameValuePair("code", code));

		post.setHeader("Content-Type", "application/x-www-form-urlencoded");

		post.setEntity(new UrlEncodedFormEntity(paramList));

		HttpResponse response = client.execute(post);

		int responseCode = response.getStatusLine().getStatusCode();
		if (debugLogs) {
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + paramList);
			System.out.println("Response Code : " + responseCode);
			System.out.println("Response  : " + response);
		}
		if (responseCode != 200) {

			System.out
					.println("\n Invalid Access Code.It may be Expired,Retry with new Access Code . Error Code : "
							+ responseCode);
			return null;
		}

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}

		if (debugLogs) {
			System.out.println(result.toString());
		}
		JSONObject authResponseJson = new JSONObject(result.toString());
		String accessToken = (String) authResponseJson.get("access_token");
		if (debugLogs) {
			System.out.println(accessToken);
		}
		AuthResponse authResponse = new AuthResponse();
		authResponse.setAccessToken(accessToken);
		// authResponse.setExpiresOn(expiresOn);
		return authResponse;

	}

	public List<UserDetails> findRole(String userId, String accessToken,
			boolean debugLogs) throws Exception {
		List<UserDetails> userDetails = new ArrayList<UserDetails>();
		String auth = "Bearer " + accessToken;
		String userPrincipal =getUserPrincipal(userId, accessToken, debugLogs);

		HttpGet request = new HttpGet(
				"https://graph.windows.net/wal-mart.com/users/"
						+ userPrincipal
						+ "/directReports?api-version=1.6");

		request.setHeader("Authorization", auth);

		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();

		if (debugLogs) {
			System.out.println("\nSending 'GET' request to get reports  : "
					+ userId);
			System.out.println("Response Code : " + responseCode);
			System.out.println(response);
		}
		if (200 == responseCode) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			if (null != userJsonResponse.get("value")) {
				JSONArray userJsonArray = (JSONArray) userJsonResponse
						.get("value");
				if (!userJsonArray.isNull(0)) {
					for (int i = 0; i < userJsonArray.length(); i++) {
						UserDetails userDetail = new UserDetails();

						if (null != userJsonArray.get(i)) {
							JSONObject user = new JSONObject(userJsonArray.get(
									i).toString());
							if (null != user.get("mail")) {
								userDetail
										.setEmail(user.get("mail").toString());
							}
							if (null != user.get("displayName")) {
								userDetail.setDisplayName(user.get(
										"displayName").toString());
							}
							if (null != user.get("telephoneNumber")) {
								userDetail.setPhone(user.get("telephoneNumber")
										.toString());
							}
							if (null != user.get("mailNickname")) {
								userDetail.setUserId(user.get("mailNickname")
										.toString());
							}
							if (null != user.get("jobTitle")) {
								userDetail.setJobTitle(user.get("jobTitle")
										.toString());
							}
							if (null != user.get("department")) {
								userDetail.setDepartment(user.get("department")
										.toString());
							}
							if (null != user.get("userPrincipalName")) {
								userDetail.setPrincipleName(user.get(
										"userPrincipalName").toString());
							}
							getManagerDetails(userDetail, accessToken,
									debugLogs);
							userDetails.add(userDetail);
						}
					}
				}
			}
		}
		return userDetails;

	}

	private UserDetails getManagerDetails(UserDetails userDetails,
			String accessToken, boolean debugLogs)
			throws ClientProtocolException, IOException, JSONException {

		String auth = "Bearer " + accessToken;

		HttpGet request = new HttpGet(
				"https://graph.windows.net/wal-mart.com/users/"
						+ userDetails.getPrincipleName()
						+ "/manager?api-version=1.6");

		request.setHeader("Authorization", auth);

		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		if (debugLogs) {
			System.out
					.println("\nSending 'GET' request to get user manager details : "
							+ userDetails.getUserId());
			System.out.println("Response Code : " + responseCode);
			System.out.println(response);
		}
		if (200 == responseCode) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			userDetails.setReportsTo((String) userJsonResponse
					.get("displayName"));
			userDetails.setManegerEmail((String) userJsonResponse.get("mail"));
		}
		return userDetails;

	}

	public List<UserDetails> getUser(List<String> userIds, String accessToken,
			boolean debugLogs) throws Exception {
		List<UserDetails> userDetails = new ArrayList<UserDetails>();
		String auth = "Bearer " + accessToken;
		for (String userId : userIds) {

			HttpGet request = new HttpGet(
					"https://graph.windows.net/wal-mart.com/users?$filter=mailNickname%20eq%20%27"
							+ userId + "%27&api-version=1.6");

			request.setHeader("Authorization", auth);

			HttpResponse response = client.execute(request);
			int responseCode = response.getStatusLine().getStatusCode();
			if (debugLogs) {
				System.out.println("\nSending 'GET' request to get user  : "
						+ userId);
				System.out.println("Response Code : " + responseCode);
				System.out.println(response);
			}

			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			if (debugLogs) {
				System.out.println(result.toString());
			}
			JSONObject userJsonResponse = new JSONObject(result.toString());

			JSONArray userJsonArray = (JSONArray) userJsonResponse.get("value");
			if (userJsonArray.length() == 0) {
				UserDetails userDetail = new UserDetails();
				userDetail.setUserId(userId);
				userDetails.add(userDetail);

			}

			for (int i = 0; i < userJsonArray.length(); i++) {
				UserDetails userDetail = new UserDetails();
				JSONObject user = new JSONObject(userJsonArray.get(i)
						.toString());
				if (null != user.get("mail")) {
					userDetail.setEmail(user.getString("mail"));
				}
				if (null != user.get("displayName")) {
					userDetail.setDisplayName(user.getString("displayName"));
				}
				if (null != user.get("telephoneNumber")) {
					userDetail.setPhone(user.getString("telephoneNumber"));
				}
				if (null != user.get("mailNickname")) {
					userDetail.setUserId(user.getString("mailNickname"));
				}
				if (null != user.get("jobTitle")) {
					userDetail.setJobTitle(user.getString("jobTitle"));
				}

				userDetails.add(userDetail);
			}

		}
		return userDetails;

	}

	public String getUserPrincipal(String userId, String accessToken,
			boolean debugLogs) throws Exception {
		String userPrincipal = null;
		String auth = "Bearer " + accessToken;

		HttpGet request = new HttpGet(
				"https://graph.windows.net/wal-mart.com/users?$filter=mailNickname%20eq%20%27"
						+ userId + "%27&api-version=1.6");

		request.setHeader("Authorization", auth);

		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		if (debugLogs) {
			System.out.println("\nSending 'GET' request to get user  : "
					+ userId);
			System.out.println("Response Code : " + responseCode);
			System.out.println(response);
		}

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		if (debugLogs) {
			System.out.println(result.toString());
		}
		JSONObject userJsonResponse = new JSONObject(result.toString());

		JSONArray userJsonArray = (JSONArray) userJsonResponse.get("value");
		if (null != userJsonArray.get(0)) {
			JSONObject user = new JSONObject(userJsonArray.get(0).toString());
			if (null != user.get("userPrincipalName")) {
				userPrincipal = (user.getString("userPrincipalName"));
			}
		}
		return userPrincipal;

	}

}