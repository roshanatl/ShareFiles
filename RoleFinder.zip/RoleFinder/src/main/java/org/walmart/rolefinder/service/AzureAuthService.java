package org.walmart.rolefinder.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.walmart.rolefinder.bean.AuthRequest;
import org.walmart.rolefinder.bean.AuthResponse;
import org.walmart.rolefinder.bean.UserDetails;
import org.walmart.rolefinder.util.AzureClientUtil;

public class AzureAuthService {
	private static AzureClientUtil client = new AzureClientUtil();
	static AuthResponse savedAuthResponse = null;

	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
			System.out
					.println("Please provide a valid agruments as [1] mode :Role/Contact [2] config json : json file with access Code & input params. ");
			return;
		}
		String accessCode = null;

		if (null == args[0]) {
			System.out
					.println("Please provide a Role Finder Mode : Role/Contact");
			return;
		}
		JSONObject configJson = parseInput(args);
		accessCode = configJson.getString("AccessCode");

		boolean debugLogs = false;
		String mode = args[0];
		if (args.length > 2 && null != args[2] && "-d".equals(args[2])) {

			debugLogs = true;
		}
		AuthResponse authRes = client.getToken(accessCode, debugLogs);
		if (null == authRes) {
			return;
		}

		if (mode.equals("Role")) {
			String userId = null;
			String searchers = null;

			if (null != configJson.getString("SearchId")) {
				userId = configJson.getString("SearchId");
			}
			if (null != configJson.getString("Searchers")) {
				searchers = configJson.getString("Searchers");
			}
			JSONArray searchJson = new JSONArray(searchers);
			Set<String> searchSet = new HashSet<String>();
			for (int i = 0; i < searchJson.length(); i++) {
				searchSet.add(searchJson.getJSONObject(i).getString(
						"SearchText"));
			}

			List<UserDetails> users = getRoleDetails(userId,
					authRes.getAccessToken(), searchSet, debugLogs);
			File output = downloadRoles(users, debugLogs);
			System.out.println("Output Generated in :" + output.getName());

		} else if (mode.equals("Contact")) {

			String userIds = null;

			if (null != configJson.getString("SearchId")) {
				userIds = configJson.getString("SearchId");
			}
			List<UserDetails> users = client.getUser(
					Arrays.asList(userIds.toString().split(",")),
					authRes.getAccessToken(), debugLogs);
			File output = downloadContacts(users, debugLogs);

			System.out.println("Output Generated in :" + output.getName());
		}

	}

	private static JSONObject parseInput(String[] args) throws IOException {
		BufferedReader b = null;
		JSONObject configJson = null;
		try {
			String inputFileString = args[1];
			File inputFile = new File(inputFileString);
			b = new BufferedReader(new FileReader(inputFile));
			String readLine = "";
			StringBuilder inputJson = new StringBuilder();

			while ((readLine = b.readLine()) != null) {
				inputJson.append(readLine);
			}

			configJson = new JSONObject(inputJson.toString());

		} catch (Exception e) {
			System.out.println("Invalid Config JSON. Please correct."
					+ e.getMessage());

		} finally {
			b.close();
		}
		return configJson;
	}

	public AuthResponse getAccessToken(AuthRequest authRequest,
			boolean debugLogs) {
		AuthResponse authResponse = null;
		try {
			authResponse = client.getToken(authRequest.getCode(), debugLogs);
			savedAuthResponse = authResponse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return authResponse;
	}

	public List<UserDetails> getUserDetails(List<String> userId,
			String accesToken, boolean debugLogs) {
		List<UserDetails> userDetails = null;
		try {
			userDetails = (List<UserDetails>) client.getUser(userId,
					accesToken, debugLogs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userDetails;
	}

	public static List<UserDetails> getRoleDetails(String userId,
			String accesToken, Set<String> searchSet, boolean debugLogs) {
		List<UserDetails> userDetails = null;
		List<UserDetails> userDetailsInner = null;
		List<UserDetails> userDetailsOuter = null;
		Boolean exitLoop = false;
		Map<String, UserDetails> userMapStore = new LinkedHashMap<String, UserDetails>();
		try {
			// Get the reports of user level 0

			userDetails = (List<UserDetails>) client.findRole(userId,
					accesToken, debugLogs);
			// add to map store
			addtoMap(userDetails, userMapStore, searchSet, debugLogs);
			// loop through each reports & find reports.
			if (null != userDetails && !userDetails.isEmpty()) {
				userDetailsOuter = userDetails;

				// Loop the first level
				System.out.println("**************************************level 2");
				List<List<UserDetails>> responseslevel1= addResponses(userDetailsOuter, userMapStore, accesToken,
						searchSet, debugLogs);
				List<List<List<UserDetails>>> responseslevel2 = new LinkedList<List<List<UserDetails>>>();
				for(List<UserDetails> each :responseslevel1){
					responseslevel2.add(addResponses(each, userMapStore, accesToken,
							searchSet, debugLogs));
				}
				
				System.out.println("**************************************level 3");
				
				List<List<List<UserDetails>>> responseslevel3 = new LinkedList<List<List<UserDetails>>>();
				for(List<List<UserDetails>> each : responseslevel2){
					for(List<UserDetails> inEach :each){
						responseslevel3.add(addResponses(inEach, userMapStore, accesToken,
								searchSet, debugLogs));
					}
					
				}
				
				System.out.println("**************************************level 4");
				List<List<List<UserDetails>>> responseslevel4 = new LinkedList<List<List<UserDetails>>>();
				for(List<List<UserDetails>> each : responseslevel3){
					for(List<UserDetails> inEach :each){
						responseslevel4.add(addResponses(inEach, userMapStore, accesToken,
								searchSet, debugLogs));
					}
					
				}
				
				System.out.println("**************************************level 5");
				
				List<List<List<UserDetails>>> responseslevel5 = new LinkedList<List<List<UserDetails>>>();
				for(List<List<UserDetails>> each : responseslevel4){
					for(List<UserDetails> inEach :each){
						responseslevel5.add(addResponses(inEach, userMapStore, accesToken,
								searchSet, debugLogs));
					}
					
				}
				/*
				System.out.println("**************************************level 6");
				
				List<List<List<UserDetails>>> responseslevel6 = new LinkedList<List<List<UserDetails>>>();
				for(List<List<UserDetails>> each : responseslevel5){
					for(List<UserDetails> inEach :each){
						responseslevel6.add(addResponses(inEach, userMapStore, accesToken,
								searchSet, debugLogs));
					}
					
				}
			*/
				// End of level 1
			
			}// End of While loop.
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ArrayList<UserDetails>(userMapStore.values());
	}

	private static List<List<UserDetails>> addResponses(List<UserDetails> userDetailsOuter,
			Map<String, UserDetails> userMapStore, String accesToken,
			Set<String> searchSet, boolean debugLogs) throws Exception {
		List<UserDetails> userDetailsInner = null;
		List<List<UserDetails>> responses = null;
		List<Boolean> status = new LinkedList<Boolean>();
		responses = new LinkedList<List<UserDetails>>();
		for (UserDetails user : userDetailsOuter) {

			System.out.println("fetching for " + user.getUserId());
			userDetailsInner = (List<UserDetails>) client.findRole(
					user.getUserId(), accesToken, debugLogs);
			responses.add(userDetailsInner);
			// add to map store
			if (null == userDetailsInner || userDetailsInner.isEmpty()) {
				status.add(false);
			} else {

				status.add(true);
				addtoMap(userDetailsInner, userMapStore, searchSet, debugLogs);
			}
		}
		return responses;
	}

	private static Map<String, UserDetails> addtoMap(List<UserDetails> users,
			Map<String, UserDetails> userMapStore, Set<String> searchSet,
			boolean debugLogs) {
		if (debugLogs) {
			System.out.println("Filters Used  : " + searchSet);
		}

		for (UserDetails user : users) {
			if (StringUtils.indexOfAny(user.getJobTitle(),
					searchSet.toArray(new String[searchSet.size()])) != -1) {
				userMapStore.put(user.getUserId(), user);
				if (debugLogs) {
					System.out.println("Passed Filter : "
							+ user.getDisplayName() + " role is :"
							+ user.getJobTitle());
				}
			} else {
				if (debugLogs) {
					System.out.println("Ignoring User in Filter : "
							+ user.getDisplayName() + " role is :"
							+ user.getJobTitle());
				}
			}
		}

		return userMapStore;
	}

	private static File downloadRoles(List<UserDetails> users, boolean debugLogs)
			throws FileNotFoundException {
		String fileNameDate = new SimpleDateFormat("yyyyMMddHHmm'.csv'")
				.format(new Date());
		String fileName = "Output_Role_Finder_" + fileNameDate;
		File file = null;
		PrintWriter pw = null;
		// Retrieve the file
		try {
			file = new File(fileName);
			pw = new PrintWriter(file);
			StringBuilder sbTitle = new StringBuilder();
			sbTitle.append("UserID$Name$Title$Department$EmailID$PhoneNo$Reports To$Manager's Email");
			pw.println(sbTitle.toString());

			for (UserDetails user : users) {
				StringBuilder sb = new StringBuilder();
				sb.append(user.getUserId());
				sb.append('$');
				apendFeild(sb, user.getDisplayName(), false);
				apendFeild(sb, user.getJobTitle(), false);
				apendFeild(sb, user.getDepartment(), false);
				apendFeild(sb, user.getEmail(), false);
				apendFeild(sb, user.getPhone(), false);
				apendFeild(sb, user.getManegerEmail(), false);
				apendFeild(sb, user.getReportsTo(), true);

				pw.println(sb.toString());
				if (debugLogs) {
					System.out.println("done!");
				}
			}

		} catch (Exception e) {
			System.out
					.println("Something Wrong with generated output File. Error :"
							+ e.getMessage());
		} finally {

			pw.close();
		}
		return file;
	}

	private static File downloadContacts(List<UserDetails> users,
			boolean debugLogs) throws FileNotFoundException {
		String fileNameDate = new SimpleDateFormat("yyyyMMddHHmm'.txt'")
				.format(new Date());
		String fileName = "Output_Contact_Finder_" + fileNameDate;
		File file = null;
		PrintWriter pw = null;
		// Retrieve the file
		try {
			file = new File(fileName);
			pw = new PrintWriter(file);

			for (UserDetails user : users) {
				StringBuilder sb = new StringBuilder();
				apendFeild(sb, user.getUserId(), false);
				apendFeild(sb, user.getDisplayName(), false);
				apendFeild(sb, user.getJobTitle(), false);
				apendFeild(sb, user.getEmail(), false);
				apendFeild(sb, user.getPhone(), true);

				pw.println(sb.toString());

				if (debugLogs) {
					System.out.println("done!");
				}
			}
		} catch (Exception e) {
			System.out
					.println("Something Wrong with generated output File. Error :"
							+ e.getMessage());
		} finally {

			pw.close();
		}
		return file;
	}

	private static void apendFeild(StringBuilder sb, String value, boolean last) {
		if (null == value) {
			return;
		}
		if (value != null && !value.equals("null")) {
			sb.append(value);
			if (!last) {
				sb.append('$');
			}
		} else if (value.equals("null")) {
			if (!last) {
				sb.append('$');
			}
		}

	}

}
