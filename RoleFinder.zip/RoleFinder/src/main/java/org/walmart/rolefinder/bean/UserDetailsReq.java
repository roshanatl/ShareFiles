package org.walmart.rolefinder.bean;

import java.util.List;

public class UserDetailsReq {
	private List<String> userIds;

	/**
	 * @return the userIds
	 */
	public List<String> getUserIds() {
		return userIds;
	}

	/**
	 * @param userIds the userIds to set
	 */
	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}

}
