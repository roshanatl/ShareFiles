console.log('oauth.js loaded');

OAUTH = function(x){
    x= x || {}
    // defaults
    this.url = x.url || 'https://login.microsoftonline.com/common/oauth2/authorize'
    this.clientId= x.clientId || '5103f34b-35e7-47d3-add7-3e6529a96a78'
    this.redirect_uri= x.redirect_uri || location.href.replace(/\?$/,'')
    this.login = function(){
        localStorage.setItem('msdnOauthConfig',JSON.stringify(this))
        location.href=this.url+'?response_type=code&redirect_uri='+this.redirect_uri+'&client_id='+this.clientId
        localStorage.log=this.url+'?response_type=tokenId&redirect_uri='+this.redirect_uri+'&client_id='+this.clientId
    }
}
OAUTH.getId=function(){
    var oth = JSON.parse(localStorage.msdnOauth)
    var config = {
        instance: 'https://login.microsoftonline.com/',
        tenant: 'wal-mart.com',
        clientId: '5103f34b-35e7-47d3-add7-3e6529a96a78',
        postLogoutRedirectUri: location.origin+location.pathname,
        cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.
    };
    var authContext = new AuthenticationContext(config)
    authContext.login()
    4
}

// in case this is being run for show in the oauth sandbox

if(document.getElementById('oauthDiv')){
    var h = '<h3>Azure AD Contact & Role Finder<i id="gitIcon"  aria-hidden="true" style="color:maroon"></i> <div><h4> <span style="color:blue">Click this button clear finder:</span>  <i id="offIcon" class="fa fa-power-off" aria-hidden="true" style="color:maroon" onclick="location.href=location.href.split(/[?#]/)[0]"></i></h4> </div> </h3>'
    h +='<div id="oauthFun">...</div>'
     h +='<div id="oauthFun1">...</div>'
    // embelish github icon
    oauthDiv.innerHTML=h
    offIcon.onmouseover=gitIcon.onmouseover=function(){
        this.style.color='red'
    }
    offIcon.onmouseleave=gitIcon.onmouseleave=function(){
        this.style.color='maroon'
    }
    // oauth fun now
    var h = '<h4></h4>'
    if((location.search.length==0)&(!localStorage.msdnOauth)){ // not logged in
        h += 'You are not logged in <button id="loginBt" class="btn btn-primary">Log In</button>  </br>'
        oauthFun.innerHTML=h
        loginBt.onclick=function(){
            (new OAUTH).login()
            //(new OAUTH).getId()
        }
    }else{
        h += 'You are logged in, <button id="logoutBt" class="btn btn-success">Log Out</button> </br>'
        if(location.search.length>0){ // collect login credentials
            var str = location.search.slice(1)
            var oth={}
            str.split('&').forEach(function(av){
                av = av.split('=')
                oth[av[0]]=av[1]
            })
            localStorage.msdnOauth=JSON.stringify(oth)
        }
        oth=JSON.parse(localStorage.msdnOauth)
        if(localStorage.msdnOauthConfig){ // there is more
            var moreOth = JSON.parse(localStorage.msdnOauthConfig)
            for( var a in moreOth){
                oth[a]=moreOth[a]
            }
            localStorage.removeItem('msdnOauthConfig')
            localStorage.setItem('msdnOauth',JSON.stringify(oth))
            localStorage.setItem('msdnOauthLast',JSON.stringify(oth))
        }
       // h += '<h5 style="color:blue">Login info found at localStorage.msdnOauth:</h5>'
        h += '<pre>'+JSON.stringify(oth,null,3)+'</pre><span style="color:navy">If you are developing a proxy service, you can now send the <span style="color:green">code value</span> above to your service from where you can get user identity as described in <a href="https://graph.microsoft.io/en-us/docs/authorization/app_authorization" target="_blank">this documentation</a>. That apporach will have your service POST the code value, the application id, application secret and redirect uri to <span style="color:green">https://login.microsoftonline.com/common/oauth2/token HTTP/1.1</span>. If you are instead developing a real Web App (what MS calls a "single page Application"), then we have to take a <a href="https://azure.microsoft.com/en-us/documentation/articles/active-directory-authentication-scenarios/#single-page-application-spa" target="_blank">different route</a>:</span><div id="getId" style="color:red"><div><button button id="getIdBt" class="btn btn-info" >Role Finder</button></div> ... not coded yet</div>'
        h += '</br><div><button button id="getIdBt" class="btn btn-info" >Role Finder</button> <button button id="getIdBtContact" class="btn btn-info" >Contact Finder</button></div>'
        oauthFun.innerHTML=h
        logoutBt.onclick=function(){
            localStorage.removeItem('msdnOauth')
            location.search=''
        }
        // getId
        
        getIdBt.onclick=function(){
        	//location.href=location.href.split(/[?#]/)[0];
        	
    		var jsondata = {"code":""};
    		var oth = JSON.parse(localStorage.msdnOauth)
    		jsondata.code=oth.code;
       
    		$.ajax({
                url: 'rest/auth',
    			//url: 'http://localhost:8080/abzooba/parseText',
                type: 'POST',
                data: JSON.stringify(jsondata),
                cache: false,
    			crossDomain : true,
                //dataType: 'json',
                processData: false, // Don't process the files
                contentType: 'application/json', // Set content type to false as jQuery will tell the server its a query string request
                success: function(data, textStatus, jqXHR )
                {
                	if(typeof data.error === 'undefined')
                	{
                	
    				 // var tabledata = gettableData(data);
                		
                		showMenu(data);	
                	}
                	else
                	{
                   	   // Handle errors here
                		console.log('ERRORS: ' + data.error);
                	}
                },
                error: function(jqXHR, textStatus, errorThrown)
                {
                	// Handle errors here
                	console.log('ERRORS: ' + textStatus);
                	// STOP LOADING SPINNER
                }
            });
        
        }
        
getIdBtContact.onclick=function(){
	//location.href=location.href.split(/[?#]/)[0]
	
    		var jsondata = {"code":""};
    		var oth = JSON.parse(localStorage.msdnOauth)
    		jsondata.code=oth.code;
       
    		$.ajax({
                url: 'rest/auth',
                type: 'POST',
                data: JSON.stringify(jsondata),
                cache: false,
    			crossDomain : true,
                //dataType: 'json',
                processData: false, // Don't process the files
                contentType: 'application/json', // Set content type to false as jQuery will tell the server its a query string request
                success: function(data, textStatus, jqXHR )
                {
                	if(typeof data.error === 'undefined')
                	{
                	
                		showMenu1(data);	
                	}
                	else
                	{
                   	   // Handle errors here
                		console.log('ERRORS: ' + data.error);
                	}
                },
                error: function(jqXHR, textStatus, errorThrown)
                {
                	// Handle errors here
                	console.log('ERRORS: ' + textStatus);
                	// STOP LOADING SPINNER
                }
            });
        
        }
        
    }
}



if(location.href.match('#id_token')){ 
    // if this is a return from a login
    localStorage.msdnOauthToken=location.hash.split('=')[1]
    var config = {
        instance: 'https://login.microsoftonline.com/',
        tenant: 'wal-mart.com',
        clientId: '67912ec2-711d-45bc-bfb9-4e6a5938f673',
        postLogoutRedirectUri: location.origin+location.pathname,
        cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.
    };
    var authContext = new AuthenticationContext(config)
    4

}


function showMenu(authJson){
	
	if(document.getElementById('oauthDiv')){
		
		 h += '<div id="myapp">'
		 h += '<h1>Role Finder</h1>'
		 h += '<h5 style="color:blue">Provide userId to fetch the details.</h5>'
		 h += '<form action="/role-finder/rest/auth/download?accesToken='+authJson.accessToken+'" method="GET"> '
		 h += '	<p><label for="name">UserID:</label> '
		 h += '<input type="text" name="userId" size="50"></p>'
		 h += '<input type="hidden" name="accesToken" value='+authJson.accessToken+'>'
		 h += '<input type="submit" value="Fetch Roles" /> '
		 h += '</form></div>'
		
		 oauthFun.innerHTML=h;
	}
	
	
	
}

function showMenu1(authJson){
	
	if(document.getElementById('oauthDiv')){
		
		 h += '<div id="myapp">'
		 h += '<h1>Contact Finder</h1>'
		 h += '<h5 style="color:blue">Provide userIds to fetch the details.</h5>'
		 h += '<form action="/role-finder/rest/auth/downloadContacts?accesToken='+authJson.accessToken+'" method="GET"> '
		 h += '	<p><label for="name">UserIDs:</label> '
		 h += '<input type="text" name="userId" size="200"></p>'
		 h += '<input type="hidden" name="accesToken" value='+authJson.accessToken+'>'
		 h += '<input type="submit" value="Fetch contacts" /> '
		 h += '</form> </div>'
			
		 oauthFun.innerHTML=h;
	}
	
	
	
}

